﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_6
{
    public partial class Form1 : Form
    {
        //card class
        class Card
        {
            public string face { get; set; }
            public string suit { get; set; }
            public int ace_value { get; set; } = 11;
            //blank constructor
            public Card()
            {
                //empty
            }
            //second constructor with two input parameters
            Card(string f, string s)
            {
                //set face to the f string input
                face = f;
                //set suit to the s string input
                suit = s;
            }
            //the setter and getter for the face variable
            public string Face
            {
                //get the face string variable
                get { return face; }
                //set the face string variable
                set { face = value; }
            }
            //the setter and getter for the suit variable
            public string Suit
            {
                //get the suit string variable
                get { return suit; }
                //set the suit string variable 
                set { if (value.GetType() == suit.GetType()) { suit = value; } }
            }

            public int Ace_value
            {
                //get the suit string variable
                get { return ace_value; }
                //set the suit string variable 
                set { ace_value = value; }
            }
            //get the blackjack value of the card
            public int Getvalue()
            {
                //temp integer to hold the value
                int vally = 0;
                //face switch cases
                switch (face)
                {
                    case "two":
                        vally = 2;
                        break;
                    case "three":
                        vally = 3;
                        break;
                    case "four":
                        vally = 4;
                        break;
                    case "five":
                        vally = 5;
                        break;
                    case "six":
                        vally = 6;
                        break;
                    case "seven":
                        vally = 7;
                        break;
                    case "eight":
                        vally = 8;
                        break;
                    case "nine":
                        vally = 9;
                        break;
                    case "joker":
                    case "king":
                    case "queen":
                    case "ten":
                        vally = 10;
                        break;
                    case "ace":
                        vally = 11;
                        break;
                    default:
                        vally = 0;
                        break;
                }
                //return the value
                return vally;
            }
            public string filename()
            {
                string tempy = "";

                tempy = Tostring().Substring(0, 2);
                //return the path to the cards
                return tempy;
            }
            //to string method
            public string Tostring()
            {
                //temp string for use later
                string tempy = "";

                switch (suit)
                {
                    case "spade":
                        tempy += "S";
                        break;
                    case "hearts":
                        tempy += "H";
                        break;
                    case "diamonds":
                        tempy += "D";
                        break;
                    case "clubs":
                        tempy += "C";
                        break;
                    default:
                        break;
                }
                switch (face)
                {
                    case "ace":
                        tempy += "A ";
                        break;
                    case "king":
                        tempy += "K ";
                        break;
                    case "two":
                        tempy += "2 ";
                        break;
                    case "three":
                        tempy += "3 ";
                        break;
                    case "four":
                        tempy += "4 ";
                        break;
                    case "five":
                        tempy += "5 ";
                        break;
                    case "six":
                        tempy += "6 ";
                        break;
                    case "seven":
                        tempy += "7 ";
                        break;
                    case "eight":
                        tempy += "8 ";
                        break;
                    case "nine":
                        tempy += "9 ";
                        break;
                    case "ten":
                        tempy += "10 ";
                        break;
                    case "queen":
                        tempy += "Q ";
                        break;
                    case "joker":
                        tempy += "J ";
                        break;
                    default:
                        break;
                }


                //return the face and suit values
                return tempy;
            }
        }
        //cardgroupclass
        class Cardgroup
        {
            //card array
            Card[] cardarry;
            //number of cards in the current group
            public int numcards { get; set; }
            //default constructor
            public Cardgroup()
            {
                //set the array to size 52
                cardarry = new Card[52];
                //set the numcards to zero
                numcards = 0;
            }
            //get the card array
            public Card[] get_cardarray()
            {
                return cardarry;
            }
            //setter and getter for numcards
            public int Numcards
            {
                //get the numcards
                get { return numcards; }
                //set the numcards
                set { numcards = value; }
            }
            //method to get the card at position i
            public Card GetCard(int i)
            {
                //returns the card at index i
                return cardarry[i];
            }
            //method to set the card at position i to be card c
            public void SetCard(int i, Card c)
            {
                //set card at position i to be c
                cardarry[i] = c;
            }
            //add card c to the end of the deck
            public void AddtoDeck(Card c)
            {
                for (int i = 0; i < cardarry.Length; i++)
                {
                    if (cardarry[i] == null)
                    {
                        cardarry[i] = c;
                        break;
                    }
                }
            }
            //make the whole deck
            public void MakeWholeDeck()
            {
                for (int i = 0; i < cardarry.Length; i++)
                {
                    cardarry[i] = new Card();
                }
                //make the spades
                for (int i = 0; i < 13; i++)
                {
                    switch (i)
                    {
                        case 0:
                            cardarry[i].face = "ace";
                            cardarry[i].suit = "spade";
                            break;
                        case 1:
                            cardarry[i].face = "king";
                            cardarry[i].suit = "spade";
                            break;
                        case 2:
                            cardarry[i].face = "two";
                            cardarry[i].suit = "spade";
                            break;
                        case 3:
                            cardarry[i].face = "three";
                            cardarry[i].suit = "spade";
                            break;
                        case 4:
                            cardarry[i].face = "four";
                            cardarry[i].suit = "spade";
                            break;
                        case 5:
                            cardarry[i].face = "five";
                            cardarry[i].suit = "spade";
                            break;
                        case 6:
                            cardarry[i].face = "six";
                            cardarry[i].suit = "spade";
                            break;
                        case 7:
                            cardarry[i].face = "seven";
                            cardarry[i].suit = "spade";
                            break;
                        case 8:
                            cardarry[i].face = "eight";
                            cardarry[i].suit = "spade";
                            break;
                        case 9:
                            cardarry[i].face = "nine";
                            cardarry[i].suit = "spade";
                            break;
                        case 10:
                            cardarry[i].face = "ten";
                            cardarry[i].suit = "spade";
                            break;
                        case 11:
                            cardarry[i].face = "queen";
                            cardarry[i].suit = "spade";
                            break;
                        case 12:
                            cardarry[i].face = "joker";
                            cardarry[i].suit = "spade";
                            break;
                        default:
                            break;
                    }
                }
                //make the clubs
                for (int i = 13; i < 26; i++)
                {
                    switch (i)
                    {
                        case 13:
                            cardarry[i].face = "ace";
                            cardarry[i].suit = "clubs";
                            break;
                        case 14:
                            cardarry[i].face = "king";
                            cardarry[i].suit = "clubs";
                            break;
                        case 15:
                            cardarry[i].face = "two";
                            cardarry[i].suit = "clubs";
                            break;
                        case 16:
                            cardarry[i].face = "three";
                            cardarry[i].suit = "clubs";
                            break;
                        case 17:
                            cardarry[i].face = "four";
                            cardarry[i].suit = "clubs";
                            break;
                        case 18:
                            cardarry[i].face = "five";
                            cardarry[i].suit = "clubs";
                            break;
                        case 19:
                            cardarry[i].face = "six";
                            cardarry[i].suit = "clubs";
                            break;
                        case 20:
                            cardarry[i].face = "seven";
                            cardarry[i].suit = "clubs";
                            break;
                        case 21:
                            cardarry[i].face = "eight";
                            cardarry[i].suit = "clubs";
                            break;
                        case 22:
                            cardarry[i].face = "nine";
                            cardarry[i].suit = "clubs";
                            break;
                        case 23:
                            cardarry[i].face = "ten";
                            cardarry[i].suit = "clubs";
                            break;
                        case 24:
                            cardarry[i].face = "queen";
                            cardarry[i].suit = "clubs";
                            break;
                        case 25:
                            cardarry[i].face = "joker";
                            cardarry[i].suit = "clubs";
                            break;
                        default:
                            break;
                    }
                }
                //make the hearts
                for (int i = 26; i < 39; i++)
                {
                    switch (i)
                    {
                        case 26:
                            cardarry[i].face = "ace";
                            cardarry[i].suit = "hearts";
                            break;
                        case 27:
                            cardarry[i].face = "king";
                            cardarry[i].suit = "hearts";
                            break;
                        case 28:
                            cardarry[i].face = "two";
                            cardarry[i].suit = "hearts";
                            break;
                        case 29:
                            cardarry[i].face = "three";
                            cardarry[i].suit = "hearts";
                            break;
                        case 30:
                            cardarry[i].face = "four";
                            cardarry[i].suit = "hearts";
                            break;
                        case 31:
                            cardarry[i].face = "five";
                            cardarry[i].suit = "hearts";
                            break;
                        case 32:
                            cardarry[i].face = "six";
                            cardarry[i].suit = "hearts";
                            break;
                        case 33:
                            cardarry[i].face = "seven";
                            cardarry[i].suit = "hearts";
                            break;
                        case 34:
                            cardarry[i].face = "eight";
                            cardarry[i].suit = "hearts";
                            break;
                        case 35:
                            cardarry[i].face = "nine";
                            cardarry[i].suit = "hearts";
                            break;
                        case 36:
                            cardarry[i].face = "ten";
                            cardarry[i].suit = "hearts";
                            break;
                        case 37:
                            cardarry[i].face = "queen";
                            cardarry[i].suit = "hearts";
                            break;
                        case 38:
                            cardarry[i].face = "joker";
                            cardarry[i].suit = "hearts";
                            break;
                        default:
                            break;
                    }
                }
                //make the diamonds
                for (int i = 39; i < 52; i++)
                {
                    switch (i)
                    {
                        case 39:
                            cardarry[i].face = "ace";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 40:
                            cardarry[i].face = "king";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 41:
                            cardarry[i].face = "two";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 42:
                            cardarry[i].face = "three";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 43:
                            cardarry[i].face = "four";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 44:
                            cardarry[i].face = "five";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 45:
                            cardarry[i].face = "six";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 46:
                            cardarry[i].face = "seven";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 47:
                            cardarry[i].face = "eight";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 48:
                            cardarry[i].face = "nine";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 49:
                            cardarry[i].face = "ten";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 50:
                            cardarry[i].face = "queen";
                            cardarry[i].suit = "diamonds";
                            break;
                        case 51:
                            cardarry[i].face = "joker";
                            cardarry[i].suit = "diamonds";
                            break;
                        default:
                            break;
                    }
                }
            }
            //shuffle the deck
            public void Shuffle()
            {
                //random variable to be used shortly
                Random randy = new Random();
                Card tempcard = new Card();
                int index;
                int count = 0;
                //go through and find the length of the array till null
                for (int i = 0; i < cardarry.Length; i++)
                {
                    if (cardarry[i] != null)
                    {
                        count = i;
                    }
                }
                //randomize the array
                for (int i = 0; i < count + 1; i++)
                {
                    index = randy.Next(0, 51);
                    //set the target card's index
                    while (index == i)
                    {
                        index = randy.Next(0, 51);
                    }

                    //remember the current card
                    tempcard = cardarry[i];

                    //set the current to the target
                    cardarry[i] = cardarry[index];
                    //set the target to the one we remember
                    cardarry[index] = tempcard;
                    tempcard = new Card();
                }
            }
            //return the top of the deck
            public Card DealTopCard()
            {
                Card firstcard = cardarry[0];
                for (int i = 0; i < 52; i++)
                {
                    if (i != 51 && cardarry[i + 1] != null && cardarry[i] != null)
                    {
                        cardarry[i] = cardarry[i + 1];
                    }
                    else
                    {
                        cardarry[i] = null;
                    }
                }
                return firstcard;
            }
            //return the entire deck in string form
            public string Tostring()
            {
                //temp string
                string temptemp = "";
                foreach (var item in cardarry)
                {
                    if (item != null)
                    {
                        temptemp = temptemp + item.Tostring();
                    }
                }
                //return the combined string
                return temptemp;
            }
        }
        ListView outputty = new ListView();
        RichTextBox outout = new RichTextBox();
        Cardgroup Deck;
        PictureBox tenthcardpiccy;
        PictureBox penultimatepiccy;
        Form1 blackjack;
        //main form initilzation
        public Form1()
        {
            //change the form size
            this.Size = new Size(1000, 600);
            //change the form name
            this.Text = "Test";
            //picturebox1
            //picturebox2
            tenthcardpiccy = new PictureBox();
            tenthcardpiccy.Left = 500;
            tenthcardpiccy.Top = 450;
            tenthcardpiccy.SizeMode = PictureBoxSizeMode.AutoSize;

            Label lbl1 = new Label();
            lbl1.Text = "Tenth card";
            lbl1.Left = 500;
            lbl1.Top = 425;

            penultimatepiccy = new PictureBox();
            penultimatepiccy.Left = 600;
            penultimatepiccy.Top = 450;
            penultimatepiccy.SizeMode = PictureBoxSizeMode.AutoSize;

            Label lbl2 = new Label();
            lbl2.Text = "penultimate card";
            lbl2.Left = 600;
            lbl2.Top = 425;

            //make the output listview
            TextBox boxy = new TextBox();

            Button btn_generate = new Button();
            btn_generate.Size = new Size(100, 50);
            btn_generate.Left = 50;
            btn_generate.Top = 450;
            btn_generate.Text = "Click to start";
            outputty.Size = new Size(900, 400);

            Button btn_start = new Button();
            btn_start.Size = new Size(100, 50);
            btn_start.Left = 250;
            btn_start.Top = 450;
            btn_start.Text = "Start blackjack";
            outout.Size = new Size(1000, 400);

            btn_generate.Click += Btn_generate_Click;
            btn_start.Click += Btn_start_Click;

            this.Controls.Add(outout);
            this.Controls.Add(btn_start);
            this.Controls.Add(btn_generate);
            this.Controls.Add(tenthcardpiccy);
            this.Controls.Add(penultimatepiccy);
            this.Controls.Add(lbl1);
            this.Controls.Add(lbl2);
        }
        //make picture for picture box
        public void make_piccy(PictureBox tempy, string filename)
        {
            string face = "";
            string suit = "";
            suit = filename.Substring(0, 1);
            face = filename.Substring(1, 1);
            if (face == "1")
            {
                face = "10";
            }
            switch (suit)
            {
                case "S":
                    switch (face)
                    {
                        case "A":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.SA);
                            break;
                        case "K":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.SK);
                            break;
                        case "2":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.S2);
                            break;
                        case "3":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.S3);
                            break;
                        case "4":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.S4);
                            break;
                        case "5":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.S5);
                            break;
                        case "6":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.S6);
                            break;
                        case "7":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.S7);
                            break;
                        case "8":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.S8);
                            break;
                        case "9":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.S9);
                            break;
                        case "10":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.S10);
                            break;
                        case "Q":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.SQ);
                            break;
                        case "J":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.SJ);
                            break;
                        default:
                            break;
                    }
                    break;
                case "H":
                    switch (face)
                    {
                        case "A":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.HA);
                            break;
                        case "K":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.HK);
                            break;
                        case "2":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.H2);
                            break;
                        case "3":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.H3);
                            break;
                        case "4":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.H4);
                            break;
                        case "5":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.H5);
                            break;
                        case "6":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.H6);
                            break;
                        case "7":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.H7);
                            break;
                        case "8":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.H8);
                            break;
                        case "9":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.H9);
                            break;
                        case "10":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.H10);
                            break;
                        case "Q":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.HQ);
                            break;
                        case "J":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.HJ);
                            break;
                        default:
                            break;
                    }
                    break;
                case "D":
                    switch (face)
                    {
                        case "A":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.DA);
                            break;
                        case "K":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.DK);
                            break;
                        case "2":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.D2);
                            break;
                        case "3":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.D3);
                            break;
                        case "4":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.D4);
                            break;
                        case "5":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.D5);
                            break;
                        case "6":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.D6);
                            break;
                        case "7":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.D7);
                            break;
                        case "8":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.D8);
                            break;
                        case "9":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.D9);
                            break;
                        case "10":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.D10);
                            break;
                        case "Q":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.DQ);
                            break;
                        case "J":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.DJ);
                            break;
                        default:
                            break;
                    }
                    break;
                case "C":
                    switch (face)
                    {
                        case "A":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.CA);
                            break;
                        case "K":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.CK);
                            break;
                        case "2":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.C2);
                            break;
                        case "3":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.C3);
                            break;
                        case "4":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.C4);
                            break;
                        case "5":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.C5);
                            break;
                        case "6":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.C6);
                            break;
                        case "7":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.C7);
                            break;
                        case "8":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.C8);
                            break;
                        case "9":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.C9);
                            break;
                        case "10":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.C10);
                            break;
                        case "Q":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.CQ);
                            break;
                        case "J":
                            tempy.Image = new Bitmap(Assignment_6.Properties.Resources.CJ);
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }

        }


        int round = 1;
        int player_score = 0;
        int dealer_score = 0;
        Cardgroup dealer;
        Cardgroup player;
        Cardgroup deck;
        PictureBox player_1, player_2;
        PictureBox dealer_1;
        Label lbl_round;
        Button btn_card_draw, btn_stay;
        int playerright;
        int dealerright;
        Label lbl_dealer_score;
        Label lbl_player_score;
        private void Btn_start_Click(object sender, EventArgs e)
        {
            round = 1;
            btn_card_draw = new Button();
            btn_card_draw.Size = new Size(100, 50);
            btn_card_draw.Left = 50;
            btn_card_draw.Top = 450;
            btn_card_draw.Text = "Draw Card";
            btn_card_draw.Click += Btn_card_draw_Click;

            btn_stay = new Button();
            btn_stay.Size = new Size(100, 50);
            btn_stay.Left = 50;
            btn_stay.Top = 500;
            btn_stay.Text = "Stay";
            btn_stay.Click += Btn_stay_Click;

            Label lbl_dealer = new Label();
            lbl_dealer.Text = "Dealer";
            lbl_dealer.Left = 100;
            lbl_dealer.Top = 50;

            lbl_round = new Label();
            lbl_round.Text = "round " + round.ToString();
            lbl_round.Left = 100;
            lbl_round.Top = 150;

            lbl_dealer_score = new Label();
            lbl_dealer_score.Text = "dealer score = ";
            lbl_dealer_score.Left = 100;
            lbl_dealer_score.Top = 200;

            lbl_player_score = new Label();
            lbl_player_score.Text = "player score =";
            lbl_player_score.Left = 100;
            lbl_player_score.Top = 225;

            Label lbl_player = new Label();
            lbl_player.Text = "player";
            lbl_player.Left = 150;
            lbl_player.Top = 450;


            //make the decks
            dealer = new Cardgroup();
            player = new Cardgroup();
            deck = new Cardgroup();
            //make the picture boxes
            dealer_1 = new PictureBox();
            dealer_1.Left = 400;
            dealer_1.Top = 25;
            dealer_1.SizeMode = PictureBoxSizeMode.AutoSize;
            PictureBox dealer_2 = new PictureBox();
            dealer_2.Left = 500;
            dealer_2.Top = 25;
            dealer_2.SizeMode = PictureBoxSizeMode.AutoSize;
            dealer_2.Image = new Bitmap(Assignment_6.Properties.Resources.Back);

            //player's pictureboxes
            player_1 = new PictureBox();
            player_1.Left = 200;
            player_1.Top = 280;
            player_1.SizeMode = PictureBoxSizeMode.AutoSize;
            player_2 = new PictureBox();
            player_2.Left = player_1.Right;
            player_2.Top = 280;
            player_2.SizeMode = PictureBoxSizeMode.AutoSize;

            //round 1
            deck.MakeWholeDeck();
            deck.Shuffle();
            //give the dealer the first two cards
            dealer.AddtoDeck(deck.DealTopCard());
            dealer.AddtoDeck(deck.DealTopCard());
            //give the player the first two cards
            player.AddtoDeck(deck.DealTopCard());
            player.AddtoDeck(deck.DealTopCard());

            //set the first pictureboxes for dealer
            make_piccy(dealer_1, dealer.get_cardarray()[0].filename());

            //set the first picturebox for the player
            make_piccy(player_1, player.get_cardarray()[0].filename());
            make_piccy(player_2, player.get_cardarray()[1].filename());

            playerright = player_2.Right;
            dealerright = dealer_2.Right;

            blackjack = new Form1();
            blackjack.Controls.Clear();

            blackjack.Controls.Add(btn_card_draw);
            blackjack.Controls.Add(lbl_dealer);
            blackjack.Controls.Add(lbl_player);
            blackjack.Controls.Add(dealer_1);
            blackjack.Controls.Add(dealer_2);
            blackjack.Controls.Add(player_1);
            blackjack.Controls.Add(player_2);
            blackjack.Controls.Add(lbl_round);
            blackjack.Controls.Add(btn_stay);
            blackjack.Controls.Add(lbl_player_score);
            blackjack.Controls.Add(lbl_dealer_score);

            blackjack.Text = "Blackjack";
            blackjack.Show();
            bust_player();
        }

        public void game_restart()
        {
            player_score = 0;
            dealer_score = 0;
            round = 1;
            btn_card_draw = new Button();
            btn_card_draw.Size = new Size(100, 50);
            btn_card_draw.Left = 50;
            btn_card_draw.Top = 450;
            btn_card_draw.Text = "Draw Card";
            btn_card_draw.Click += Btn_card_draw_Click;

            btn_stay = new Button();
            btn_stay.Size = new Size(100, 50);
            btn_stay.Left = 50;
            btn_stay.Top = 500;
            btn_stay.Text = "Stay";
            btn_stay.Click += Btn_stay_Click;

            Label lbl_dealer = new Label();
            lbl_dealer.Text = "Dealer";
            lbl_dealer.Left = 100;
            lbl_dealer.Top = 50;

            lbl_round = new Label();
            lbl_round.Text = "round " + round.ToString();
            lbl_round.Left = 100;
            lbl_round.Top = 150;

            lbl_dealer_score = new Label();
            lbl_dealer_score.Text = "dealer score = ";
            lbl_dealer_score.Left = 100;
            lbl_dealer_score.Top = 200;

            lbl_player_score = new Label();
            lbl_player_score.Text = "player score =";
            lbl_player_score.Left = 100;
            lbl_player_score.Top = 225;

            Label lbl_player = new Label();
            lbl_player.Text = "player";
            lbl_player.Left = 150;
            lbl_player.Top = 450;


            //make the decks
            dealer = new Cardgroup();
            player = new Cardgroup();
            deck = new Cardgroup();
            //make the picture boxes
            dealer_1 = new PictureBox();
            dealer_1.Left = 400;
            dealer_1.Top = 25;
            dealer_1.SizeMode = PictureBoxSizeMode.AutoSize;
            PictureBox dealer_2 = new PictureBox();
            dealer_2.Left = 500;
            dealer_2.Top = 25;
            dealer_2.SizeMode = PictureBoxSizeMode.AutoSize;
            dealer_2.Image = new Bitmap(Assignment_6.Properties.Resources.Back);

            //player's pictureboxes
            player_1 = new PictureBox();
            player_1.Left = 200;
            player_1.Top = 280;
            player_1.SizeMode = PictureBoxSizeMode.AutoSize;
            player_2 = new PictureBox();
            player_2.Left = player_1.Right;
            player_2.Top = 280;
            player_2.SizeMode = PictureBoxSizeMode.AutoSize;

            //round 1
            deck.MakeWholeDeck();
            deck.Shuffle();
            //give the dealer the first two cards
            dealer.AddtoDeck(deck.DealTopCard());
            dealer.AddtoDeck(deck.DealTopCard());
            //give the player the first two cards
            player.AddtoDeck(deck.DealTopCard());
            player.AddtoDeck(deck.DealTopCard());

            //set the first pictureboxes for dealer
            make_piccy(dealer_1, dealer.get_cardarray()[0].filename());

            //set the first picturebox for the player
            make_piccy(player_1, player.get_cardarray()[0].filename());
            make_piccy(player_2, player.get_cardarray()[1].filename());

            playerright = player_2.Right;
            dealerright = dealer_2.Right;

            blackjack.Controls.Clear();

            blackjack.Controls.Add(btn_card_draw);
            blackjack.Controls.Add(lbl_dealer);
            blackjack.Controls.Add(lbl_player);
            blackjack.Controls.Add(dealer_1);
            blackjack.Controls.Add(dealer_2);
            blackjack.Controls.Add(player_1);
            blackjack.Controls.Add(player_2);
            blackjack.Controls.Add(lbl_round);
            blackjack.Controls.Add(btn_stay);
            blackjack.Controls.Add(lbl_player_score);
            blackjack.Controls.Add(lbl_dealer_score);

            blackjack.Text = "Blackjack";
            blackjack.Show();
            bust_player();
        }

        public bool bust_player()
        {
            player_score = 0;
            foreach (Card c in player.get_cardarray())
            {
                if (c != null)
                {
                    if (c.Face == "ace")
                    {
                        player_score += c.Ace_value;
                    }
                    else
                    {
                        player_score += c.Getvalue();
                    }
                    if (player_score > 21)
                    {
                        foreach (Card x in player.get_cardarray())
                        {
                            if (x != null)
                            {
                                if (x.Face == "ace" && x.Ace_value == 11)
                                {
                                    x.Ace_value = 1;
                                    player_score -= 10;
                                }
                            }
                            
                        }
                    }
                }
                
            }
            lbl_player_score.Text = "player score = " + player_score.ToString();
            if (player_score> 21)
            {
                return true;
            }

            return false;
        }

        public bool bust_dealer()
        {
            dealer_score = 0;
            foreach (Card c in dealer.get_cardarray())
            {
                if (c != null)
                {
                    if (c.Face == "ace")
                    {
                        dealer_score += c.Ace_value;
                    }
                    else
                    {
                        dealer_score += c.Getvalue();
                    }
                    if (dealer_score > 21)
                    {
                        foreach (Card x in dealer.get_cardarray())
                        {
                            if (x != null)
                            {
                                if (x.Face == "ace" && x.Ace_value == 11)
                                {
                                    x.Ace_value = 1;
                                    dealer_score -= 10;
                                }
                            }

                        }
                    }
                }

            }
            if (dealer_score > 21)
            {
                return true;
            }

            return false;
        }

        private void Btn_stay_Click(object sender, EventArgs e)
        {
            deck.Shuffle();
            bust_dealer();
            while (dealer_score < 16)
            {
                Card tempcard = new Card();
                tempcard = deck.DealTopCard();
                PictureBox tempy = new PictureBox();
                tempy.Left = dealerright;
                tempy.Top = 25;
                tempy.SizeMode = PictureBoxSizeMode.AutoSize;
                tempy.Image = new Bitmap(Assignment_6.Properties.Resources.Back);
                blackjack.Controls.Add(tempy);
                dealerright = tempy.Right;
                //give the player another card
                dealer.AddtoDeck(tempcard);
                bust_dealer();
            }

            if (bust_dealer() == true)
            {
                lbl_dealer_score.Text = "dealer score = " + dealer_score.ToString();
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;

                result = MessageBox.Show("You win, wanna go again?", "Results", buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    game_restart();
                }
                else
                {
                    blackjack.Close();
                }
            }
            else if (bust_player() == true)
            {
                lbl_dealer_score.Text = "dealer score = " + dealer_score.ToString();
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;

                result = MessageBox.Show("You loose, wanna go again?", "Results", buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    game_restart();
                }
                else
                {
                    blackjack.Close();
                }
            }
            else if (player_score > dealer_score)
            {
                lbl_dealer_score.Text = "dealer score = " + dealer_score.ToString();
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;

                result = MessageBox.Show("You Win, wanna go again?", "Results", buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    game_restart();
                }
                else
                {
                    blackjack.Close();
                }
            }
            else if (player_score <dealer_score)
            {
                lbl_dealer_score.Text = "dealer score = " + dealer_score.ToString();
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;

                result = MessageBox.Show("You loose, wanna go again?", "Results", buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    game_restart();
                }
                else
                {
                    blackjack.Close();
                }
            }
        }

        private void Btn_card_draw_Click(object sender, EventArgs e)
        {
            Card tempcard = new Card();
            tempcard = deck.DealTopCard();
            //give the player another card
            player.AddtoDeck(tempcard);
            //show the new card
            PictureBox tempy = new PictureBox();
            tempy.Left = playerright;
            tempy.Top = 280;
            tempy.SizeMode = PictureBoxSizeMode.AutoSize;
            make_piccy(tempy, tempcard.filename());
            blackjack.Controls.Add(tempy);
            playerright = tempy.Right;
            bust_dealer();
            deck.Shuffle();
            if (bust_player() == true)
            {
                bust_dealer();
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                lbl_dealer_score.Text = "dealer score = " + dealer_score.ToString();
                result = MessageBox.Show("You loose, wanna go again?","Results", buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    game_restart();
                }
                else
                {
                    blackjack.Close();
                }
            }
        }

        private void Btn_generate_Click(object sender, EventArgs e)
        {
            string face = "";
            string suit = "";
            Card temp = new Card();
            //instantiate a new card group
            Deck = new Cardgroup();
            //fill the card deck
            Deck.MakeWholeDeck();

            //print the deck
            outout.Text += "Filled the deck" + "\n";
            outout.Text += Deck.Tostring();
            outout.Text += "\n";
            outout.Text += "\n";
            //shuffle the deck
            Deck.Shuffle();
            //print the deck
            outout.Text += "Shuffled the deck" + "\n";
            outout.Text += Deck.Tostring();
            outout.Text += "\n";
            outout.Text += "\n";
            //deal the first card
            temp = Deck.DealTopCard();
            //add it to the back of the group
            Deck.AddtoDeck(temp);
            //print the deck
            outout.Text += "Fisrt value added to back of the deck" + "\n";
            outout.Text += Deck.Tostring();
            outout.Text += "\n";
            outout.Text += "\n";
            //set the tenth card
            temp = Deck.get_cardarray()[9];
            suit = temp.Tostring().Substring(0, 1);
            face = temp.Tostring().Substring(1, 1);
            if (face == "1")
            {
                face = "10";
            }
            switch (suit)
            {
                case "S":
                    switch (face)
                    {
                        case "A":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.SA);
                            break;
                        case "K":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.SK);
                            break;
                        case "2":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S2);
                            break;
                        case "3":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S3);
                            break;
                        case "4":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S4);
                            break;
                        case "5":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S5);
                            break;
                        case "6":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S6);
                            break;
                        case "7":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S7);
                            break;
                        case "8":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S8);
                            break;
                        case "9":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S9);
                            break;
                        case "10":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S10);
                            break;
                        case "Q":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.SQ);
                            break;
                        case "J":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.SJ);
                            break;
                        default:
                            break;
                    }
                    break;
                case "H":
                    switch (face)
                    {
                        case "A":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.HA);
                            break;
                        case "K":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.HK);
                            break;
                        case "2":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H2);
                            break;
                        case "3":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H3);
                            break;
                        case "4":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H4);
                            break;
                        case "5":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H5);
                            break;
                        case "6":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H6);
                            break;
                        case "7":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H7);
                            break;
                        case "8":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H8);
                            break;
                        case "9":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H9);
                            break;
                        case "10":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H10);
                            break;
                        case "Q":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.HQ);
                            break;
                        case "J":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.HJ);
                            break;
                        default:
                            break;
                    }
                    break;
                case "D":
                    switch (face)
                    {
                        case "A":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.DA);
                            break;
                        case "K":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.DK);
                            break;
                        case "2":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D2);
                            break;
                        case "3":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D3);
                            break;
                        case "4":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D4);
                            break;
                        case "5":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D5);
                            break;
                        case "6":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D6);
                            break;
                        case "7":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D7);
                            break;
                        case "8":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D8);
                            break;
                        case "9":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D9);
                            break;
                        case "10":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D10);
                            break;
                        case "Q":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.DQ);
                            break;
                        case "J":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.DJ);
                            break;
                        default:
                            break;
                    }
                    break;
                case "C":
                    switch (face)
                    {
                        case "A":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.CA);
                            break;
                        case "K":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.CK);
                            break;
                        case "2":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C2);
                            break;
                        case "3":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C3);
                            break;
                        case "4":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C4);
                            break;
                        case "5":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C5);
                            break;
                        case "6":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C6);
                            break;
                        case "7":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C7);
                            break;
                        case "8":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C8);
                            break;
                        case "9":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C9);
                            break;
                        case "10":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C10);
                            break;
                        case "Q":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.CQ);
                            break;
                        case "J":
                            tenthcardpiccy.Image = new Bitmap(Assignment_6.Properties.Resources.CJ);
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            //set the penultimate card
            temp = Deck.get_cardarray()[50];
            suit = temp.Tostring().Substring(0, 1);
            face = temp.Tostring().Substring(1, 1);
            if (face == "1")
            {
                face = "10";
            }
            switch (suit)
            {
                case "S":
                    switch (face)
                    {
                        case "A":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.SA);
                            break;
                        case "K":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.SK);
                            break;
                        case "2":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S2);
                            break;
                        case "3":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S3);
                            break;
                        case "4":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S4);
                            break;
                        case "5":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S5);
                            break;
                        case "6":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S6);
                            break;
                        case "7":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S7);
                            break;
                        case "8":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S8);
                            break;
                        case "9":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S9);
                            break;
                        case "10":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.S10);
                            break;
                        case "Q":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.SQ);
                            break;
                        case "J":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.SJ);
                            break;
                        default:
                            break;
                    }
                    break;
                case "H":
                    switch (face)
                    {
                        case "A":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.HA);
                            break;
                        case "K":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.HK);
                            break;
                        case "2":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H2);
                            break;
                        case "3":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H3);
                            break;
                        case "4":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H4);
                            break;
                        case "5":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H5);
                            break;
                        case "6":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H6);
                            break;
                        case "7":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H7);
                            break;
                        case "8":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H8);
                            break;
                        case "9":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H9);
                            break;
                        case "10":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.H10);
                            break;
                        case "Q":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.HQ);
                            break;
                        case "J":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.HJ);
                            break;
                        default:
                            break;
                    }
                    break;
                case "D":
                    switch (face)
                    {
                        case "A":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.DA);
                            break;
                        case "K":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.DK);
                            break;
                        case "2":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D2);
                            break;
                        case "3":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D3);
                            break;
                        case "4":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D4);
                            break;
                        case "5":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D5);
                            break;
                        case "6":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D6);
                            break;
                        case "7":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D7);
                            break;
                        case "8":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D8);
                            break;
                        case "9":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D9);
                            break;
                        case "10":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.D10);
                            break;
                        case "Q":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.DQ);
                            break;
                        case "J":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.DJ);
                            break;
                        default:
                            break;
                    }
                    break;
                case "C":
                    switch (face)
                    {
                        case "A":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.CA);
                            break;
                        case "K":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.CK);
                            break;
                        case "2":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C2);
                            break;
                        case "3":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C3);
                            break;
                        case "4":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C4);
                            break;
                        case "5":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C5);
                            break;
                        case "6":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C6);
                            break;
                        case "7":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C7);
                            break;
                        case "8":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C8);
                            break;
                        case "9":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C9);
                            break;
                        case "10":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.C10);
                            break;
                        case "Q":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.CQ);
                            break;
                        case "J":
                            penultimatepiccy.Image = new Bitmap(Assignment_6.Properties.Resources.CJ);
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
